﻿using Microsoft.Win32;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using System.Xml.Linq;

namespace ChooseFileXML
{
    public partial class MainWindow : Window
    {
        string FileXML;

        public MainWindow()
        {
            InitializeComponent();
        }

        public void LoadDataFromXML(string filePath)
        {
            if (filePath != null)
            {
                XDocument XML = XDocument.Load(filePath);
                List<Car> cars = new List<Car>();

                foreach (XElement element in XML.Descendants("Car"))
                {
                    cars.Add(new Car
                    {
                        Model = element.Element("Model")?.Value,
                        Cena = double.Parse(element.Element("Cena")?.Value.Replace(",-", "").Replace(".", "")),
                        DPH = double.Parse(element.Element("DPH")?.Value.Replace(",-", "").Replace(".", "")),
                    });
                }

                var groupedCars = cars.GroupBy(c => c.Model)
                .Select(group => new CarSummary
                {
                    Model = group.Key,
                    WithoutDPH = group.Sum(car => car.Cena),
                    WithDPH = group.Sum(car => car.Cena) * (1 + group.First().DPH / 100)
                }).ToList();

                CarItemsControl.ItemsSource = groupedCars;
            }
        }

        private void BtnOpenFile_Click(object sender, RoutedEventArgs e)
        {
            OpenFileDialog openFileDialog = new OpenFileDialog
            {
                Filter = "XML Files (*.xml)|*.xml|All Files (*.*)|*.*",
                Title = "Vyberte XML Soubor"
            };

            if (openFileDialog.ShowDialog() == true)
            {
                string filePath = openFileDialog.FileName;
                MessageBox.Show($"Vybraný soubor: {filePath}");
                LoadDataFromXML(filePath);
            }
        }

        public class Car
        {
            public required string Model { get; set; }
            public required double Cena { get; set; }
            public required double DPH { get; set; }
        }

        public class CarSummary
        {
            public required string Model { get; set; }
            public required double WithoutDPH { get; set; }
            public required double WithDPH { get; set; }
        }
    }
}